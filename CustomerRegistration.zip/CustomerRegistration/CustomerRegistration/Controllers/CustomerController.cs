﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using CustomerRegistration.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CustomerRegistration.Controllers
{
    public class CustomerController : Controller
    {
        private readonly CustomerContext _context;
        private readonly IWebHostEnvironment webHostEnvironment;
        public CustomerController(CustomerContext context, IWebHostEnvironment hostEnvironment)
        {
            _context = context;
            webHostEnvironment = hostEnvironment;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<ActionResult> Login(LoginViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var customerdetails = await _context.CustomerDetails.SingleOrDefaultAsync(m => m.Email == model.Email && m.Password == model.Password);
                    if (customerdetails == null)
                    {
                        ModelState.AddModelError("Password", "Invalid login attempt.");
                        return View("Index");
                    }
                    HttpContext.Session.SetString("userId", customerdetails.Name);

                }
                else
                {
                    return View("Index");
                }
                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        [HttpPost]
        public async Task<ActionResult> Registar(RegistrationViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string uniqueFileName = UploadedFile(model);
                    CustomerDetails customer = new CustomerDetails
                    {
                        Name = model.Name,
                        Email = model.Email,
                        Password = model.Password,
                        Mobile = model.Mobile,
                        //ProfileImage=uniqueFileName
                    };
                    _context.Add(customer);
                    await _context.SaveChangesAsync();
                }
                else
                {
                    return View("Registration");
                }
                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        // registration Page load
        public IActionResult Registration()
        {
            ViewData["Message"] = "Customer Registration Page";
            return View();
        }

        public async Task<IActionResult> CutomeDetails()
        {
            try
            {
                RegistrationViewModel registrationViewModel = null;
                CustomerDetails customerdetails = await _context.CustomerDetails.FirstOrDefaultAsync();
                if (customerdetails != null)
                {
                    registrationViewModel = new RegistrationViewModel
                    {
                        CustomerId = customerdetails.CustomerId,
                        Name = customerdetails.Name,
                        Email = customerdetails.Email,
                        Mobile = customerdetails.Mobile
                    };
                    return View(registrationViewModel);
                }
                return View("Index");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        public IActionResult Edit(int customerId)
        {
            try
            {
                RegistrationViewModel registrationViewModel = null;
                CustomerDetails customerdetails = _context.CustomerDetails.Where(x => x.CustomerId == customerId).FirstOrDefault();
                if (customerdetails != null)
                {
                    registrationViewModel = new RegistrationViewModel
                    {
                        CustomerId = customerdetails.CustomerId,
                        Name = customerdetails.Name,
                        Email = customerdetails.Email,
                        Mobile = customerdetails.Mobile,
                        Password = customerdetails.Password,
                    };
                    return View(registrationViewModel);
                }
                return View("Index");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPut]
        public async Task<IActionResult> Edit(RegistrationViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    CustomerDetails customer = new CustomerDetails
                    {
                        Name = model.Name,
                        Email = model.Email,
                        Password = model.Password,
                        Mobile = model.Mobile
                    };
                    _context.Update(customer);
                    await _context.SaveChangesAsync();
                }
                else
                {
                    return View("Registration");
                }
                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private string UploadedFile(RegistrationViewModel model)
        {
            string uniqueFileName = null;

            if (model.ProfileImage != null)
            {
                string uploadsFolder = Path.Combine(webHostEnvironment.WebRootPath, "images");
                uniqueFileName = Guid.NewGuid().ToString() + "_" + model.ProfileImage.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    model.ProfileImage.CopyTo(fileStream);
                }
            }
            return uniqueFileName;
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return View("Index");
        }
        public void ValidationMessage(string key, string alert, string value)
        {
            try
            {
                TempData.Remove(key);
                TempData.Add(key, value);
                TempData.Add("alertType", alert);
            }
            catch
            {
                Debug.WriteLine("TempDataMessage Error");
            }

        }
    }
}