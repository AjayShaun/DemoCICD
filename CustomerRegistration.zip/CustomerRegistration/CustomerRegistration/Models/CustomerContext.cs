﻿using Microsoft.EntityFrameworkCore;
using CustomerRegistration.Models;

namespace CustomerRegistration.Models
{
    public class CustomerContext : DbContext
    {
        public virtual DbSet<CustomerDetails> CustomerDetails { get; set; }

        public CustomerContext(DbContextOptions<CustomerContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CustomerDetails>(entity =>
            {
                entity.ToTable("CustomerDetails");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Mobile)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProfileImage)
                 .HasMaxLength(1000)
                 .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });
        }

        public DbSet<CustomerRegistration.Models.RegistrationViewModel> RegistrationViewModel { get; set; }
    }
}
